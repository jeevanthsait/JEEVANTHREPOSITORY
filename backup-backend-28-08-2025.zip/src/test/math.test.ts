describe("Math tests", () => {
  it("should add numbers correctly", () => {
    const sum = 2 + 3;
    expect(sum).toBe(5);
  });

  it("should subtract numbers correctly", () => {
    const result = 10 - 4;
    expect(result).toBe(6);
  });
});
