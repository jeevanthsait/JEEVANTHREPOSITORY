export const ROLES = {
  ADMIN: "Admin",
  USER: "User",
  SUPER_ADMIN: "Super Admin", 
} as const;
